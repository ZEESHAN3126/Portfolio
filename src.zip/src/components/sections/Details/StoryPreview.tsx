"use client";

/**
 * StoryPreview — src/components/sections/Details/StoryPreview.tsx
 *
 * Teaser card for the project's Story Mode episode viewer.
 *
 * Renders when:  project.storyMode !== undefined
 * Auto-hides when: project.storyMode === undefined
 *
 * States:
 *  • slides.length > 0  → "Watch Story" button is active (calls onWatchStory)
 *  • slides.length === 0 → "Coming Soon" disabled button
 *
 * PRD Reference: §8 Motion Design · §9 Color System
 */

import { Clapperboard, Lock, Play } from "lucide-react";
import type { StoryModeData } from "@/types/project-detail";
import { Section } from "./Section";
import { cn } from "@/lib/utils";

// ─── Types ────────────────────────────────────────────────────────────────────

interface StoryPreviewProps {
  data?: StoryModeData;
  /** Fired when the "Watch Story" CTA is clicked — parent opens StoryMode */
  onWatchStory?: () => void;
}

// ─── Component ────────────────────────────────────────────────────────────────

export function StoryPreview({ data, onWatchStory }: StoryPreviewProps) {
  if (!data) return null;

  const {
    slides,
    previewText = "A cinematic, interactive walkthrough of this project is coming soon.",
    ctaLabel = "Watch Story",
  } = data;

  const hasSlides = slides.length > 0;

  return (
    <Section title="Story">
      <div
        className="
          relative overflow-hidden
          rounded-xl
          border border-white/[0.06]
          bg-[#0D0D0D]
        "
      >
        {/* Subtle noise texture */}
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0"
          style={{
            backgroundImage:
              "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.07'/%3E%3C/svg%3E\")",
            backgroundSize: "180px",
          }}
        />

        {/* Crimson ambient */}
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 bg-gradient-to-br from-[#C8102E]/[0.05] to-transparent"
        />

        <div className="relative flex flex-col items-center justify-center px-8 py-12 text-center">

          {/* Icon */}
          <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-full border border-white/[0.08] bg-white/[0.04]">
            <Clapperboard size={22} strokeWidth={1.5} className="text-[#C8102E]" aria-hidden />
          </div>

          {/* Episode count */}
          {hasSlides && (
            <span className="mb-3 text-[0.6rem] font-bold uppercase tracking-[0.28em] text-[#C8102E]">
              {slides.length} {slides.length === 1 ? "Episode" : "Episodes"}
            </span>
          )}

          <h4 className="mb-2 text-base font-bold text-white">Interactive Story</h4>

          <p className="mb-7 max-w-xs text-sm leading-relaxed text-[#6B6B6B]">
            {previewText}
          </p>

          {/* CTA */}
          {hasSlides ? (
            <button
              type="button"
              onClick={onWatchStory}
              className={cn(
                "inline-flex items-center gap-2.5",
                "rounded-lg px-6 py-2.5",
                "bg-[#C8102E] text-sm font-bold text-white",
                "hover:bg-[#A50D26] hover:scale-[1.02] active:scale-[0.98]",
                "transition-all duration-150",
                "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#3B82F6]",
              )}
            >
              <Play size={14} fill="white" strokeWidth={0} aria-hidden />
              {ctaLabel}
            </button>
          ) : (
            <button
              type="button"
              disabled
              aria-disabled="true"
              title="Story is coming soon"
              className="inline-flex cursor-not-allowed items-center gap-2 rounded-lg border border-white/[0.08] bg-white/[0.04] px-5 py-2.5 text-sm font-semibold text-[#6B6B6B] select-none"
            >
              <Lock size={13} strokeWidth={2.5} aria-hidden />
              Coming Soon
            </button>
          )}

        </div>
      </div>
    </Section>
  );
}
